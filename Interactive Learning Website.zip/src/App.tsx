import { useEffect, useRef, useState } from "react"
import HISimulation from "./HISimulation"
import InteractiveVideoLesson, {
  initialVideoQuestions,
  VIDEO_SOURCE,
  type VideoQuestion,
} from "./InteractiveVideoLesson"
import {
  IrreversibleReaction,
  ReversibleReaction,
} from "./ReactionConcepts"

type IconName = "atom" | "book" | "video" | "flask" | "quiz" | "arrow" | "check" | "close" | "external" | "spark"

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    atom: (
      <>
        <circle cx="12" cy="12" r="1.6" fill="currentColor" />
        <ellipse cx="12" cy="12" rx="9" ry="3.8" />
        <ellipse cx="12" cy="12" rx="9" ry="3.8" transform="rotate(60 12 12)" />
        <ellipse
          cx="12"
          cy="12"
          rx="9"
          ry="3.8"
          transform="rotate(120 12 12)"
        />
      </>
    ),
    book: (
      <>
        <path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H11v16H6.5A2.5 2.5 0 0 0 4 21.5z" />
        <path d="M20 5.5A2.5 2.5 0 0 0 17.5 3H13v16h4.5a2.5 2.5 0 0 1 2.5 2.5z" />
      </>
    ),
    video: (
      <>
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <path d="m10 9 5 3-5 3z" />
      </>
    ),
    flask: (
      <path d="M9 3h6m-5 0v5.5L4.7 18a2 2 0 0 0 1.8 3h11a2 2 0 0 0 1.8-3L14 8.5V3M8 14h8" />
    ),
    quiz: (
      <>
        <rect x="4" y="3" width="16" height="18" rx="2" />
        <path d="m8 9 1.5 1.5L12 8M8 15l1.5 1.5L12 14M15 9h2M15 15h2" />
      </>
    ),
    arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
    check: <path d="m5 12 4 4L19 6" />,
    close: <path d="m6 6 12 12M18 6 6 18" />,
    external: (
      <path d="M14 4h6v6m0-6-9 9M18 13v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6" />
    ),
    spark: (
      <path d="m12 3 1.3 4.2L17 9l-3.7 1.8L12 15l-1.3-4.2L7 9l3.7-1.8zM18.5 15l.7 2.3 2.3.7-2.3.7-.7 2.3-.7-2.3-2.3-.7 2.3-.7z" />
    ),
  }

  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  )
}

type MiniSection = {
  id: string
  label: string
  icon: IconName
}

type MainSection = MiniSection & {
  children?: MiniSection[]
}

const sections: MainSection[] = [
  {
    id: "kien-thuc",
    label: "Kiến thức",
    icon: "book",
    children: [
      {
        id: "phan-ung-thuan-nghich",
        label: "Phản ứng một chiều và thuận nghịch",
        icon: "arrow",
      },
      {
        id: "trang-thai-can-bang",
        label: "Trạng thái cân bằng",
        icon: "atom",
      },
    ],
  },
  { id: "luyen-tap", label: "Luyện tập", icon: "quiz" as IconName },
  { id: "van-dung", label: "Vận dụng", icon: "spark" as IconName },
]

type Question = {
  question: string
  answers: string[]
  correct: number
  explanation: string
}

type ProgressRecord = {
  id: string
  studentName: string
  score: number
  total: number
  completedAt: string
}

const initialQuestions: Question[] = [
  {
    question: "Phản ứng thuận nghịch là phản ứng?",
    answers: [
      "Chỉ xảy ra theo một chiều nhất định.",
      "Xảy ra giữa hai chất khí.",
      "Xảy ra theo hai chiều ngược nhau trong cùng điều kiện.",
      "Có phương trình hoá học được biểu diễn bằng mũi tên một chiều.",
    ],
    correct: 2,
    explanation:
      "Phản ứng thuận nghịch có thể diễn ra đồng thời theo chiều thuận và chiều nghịch trong cùng điều kiện.",
  },
  {
    question:
      "Yếu tố nào sau đây luôn luôn không làm dịch chuyển cân bằng của hệ phản ứng?",
    answers: ["Nhiệt độ.", "Áp suất.", "Nồng độ.", "Chất xúc tác."],
    correct: 3,
    explanation:
      "Chất xúc tác làm tăng đồng thời tốc độ phản ứng thuận và nghịch, giúp hệ nhanh đạt cân bằng nhưng không làm cân bằng chuyển dịch.",
  },
]

function App() {
  const [role, setRole] = useState<"student" | "teacher" | null>(null)
  const [questionBank, setQuestionBank] = useState<Question[]>(() => {
    const stored = window.localStorage.getItem("chemlab-questions")
    return stored ? (JSON.parse(stored) as Question[]) : initialQuestions
  })
  const [progressRecords, setProgressRecords] = useState<ProgressRecord[]>(() => {
    const stored = window.localStorage.getItem("chemlab-progress")
    return stored ? (JSON.parse(stored) as ProgressRecord[]) : []
  })
  const [videoQuestions, setVideoQuestions] = useState<VideoQuestion[]>(() => {
    const stored = window.localStorage.getItem("chemlab-video-questions")
    return stored ? (JSON.parse(stored) as VideoQuestion[]) : initialVideoQuestions
  })
  const [videoSource, setVideoSource] = useState(() =>
    window.localStorage.getItem("chemlab-video-source") || VIDEO_SOURCE,
  )
  const [studentName, setStudentName] = useState("")
  const [teacherPasscode, setTeacherPasscode] = useState("")
  const [showTeacherLogin, setShowTeacherLogin] = useState(false)
  const [teacherLoginError, setTeacherLoginError] = useState("")
  const [hasStarted, setHasStarted] = useState(false)
  const [showResults, setShowResults] = useState(false)
  const [knowledgeTab, setKnowledgeTab] = useState<0 | 1>(0)
  const [activeLessonTab, setActiveLessonTab] = useState("kien-thuc")
  const [selectedAnswers, setSelectedAnswers] =
    useState<Record<number, number>>({})
  const [violationCount, setViolationCount] = useState(0)
  const [showWarning, setShowWarning] = useState(false)
  const [isLocked, setIsLocked] = useState(false)
  const violationLatched = useRef(false)
  const progressSaved = useRef(false)

  useEffect(() => {
    window.localStorage.setItem("chemlab-questions", JSON.stringify(questionBank))
  }, [questionBank])

  useEffect(() => {
    window.localStorage.setItem("chemlab-video-questions", JSON.stringify(videoQuestions))
  }, [videoQuestions])

  // Giám sát học tập: gộp blur và visibilitychange thành một lần vi phạm.
  useEffect(() => {
    const recordViolation = () => {
      if (!hasStarted || violationLatched.current || isLocked) return
      violationLatched.current = true
      setViolationCount((current) => {
        const next = current + 1
        if (next >= 3) {
          setIsLocked(true)
          setShowWarning(false)
        } else {
          setShowWarning(true)
        }
        return next
      })
    }

    const handleVisibility = () => {
      if (document.hidden) recordViolation()
      else violationLatched.current = false
    }
    const handleBlur = () => {
      // Tương tác với iframe cũng làm cửa sổ cha mất focus, nhưng không phải là rời bài học.
      window.setTimeout(() => {
        if (document.activeElement instanceof HTMLIFrameElement) return
        recordViolation()
      }, 0)
    }
    const handleFocus = () => {
      if (!document.hidden) violationLatched.current = false
    }

    document.addEventListener("visibilitychange", handleVisibility)
    window.addEventListener("blur", handleBlur)
    window.addEventListener("focus", handleFocus)
    return () => {
      document.removeEventListener("visibilitychange", handleVisibility)
      window.removeEventListener("blur", handleBlur)
      window.removeEventListener("focus", handleFocus)
    }
  }, [hasStarted, isLocked])

  const goToSection = (id: string) => {
    const nextTab = ["kham-pha", "video-bai-giang", "thi-nghiem"].includes(id)
      ? "kien-thuc"
      : id
    setActiveLessonTab(nextTab)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const answeredCount = Object.keys(selectedAnswers).length
  const score = Object.entries(selectedAnswers).filter(
    ([questionIndex, answerIndex]) =>
      questionBank[Number(questionIndex)].correct === answerIndex,
  ).length
  const hasCompletedQuiz = answeredCount === questionBank.length
  const resultLabel =
    score === questionBank.length
      ? "Xuất sắc"
      : score >= Math.ceil(questionBank.length / 2)
        ? "Đạt yêu cầu"
        : "Cần ôn tập thêm"
  const resultMessage =
    score === questionBank.length
      ? "Bạn đã nắm rất chắc các khái niệm trọng tâm của bài học."
      : score >= Math.ceil(questionBank.length / 2)
        ? "Bạn đã hoàn thành bài học. Hãy xem lại những câu trả lời chưa đúng."
        : "Hãy xem lại phần lý thuyết và thử làm lại bài luyện tập một lần nữa."

  useEffect(() => {
    if (!showResults || progressSaved.current) return
    const record: ProgressRecord = {
      id: `${Date.now()}-${studentName}`,
      studentName,
      score,
      total: questionBank.length,
      completedAt: new Date().toISOString(),
    }
    const nextRecords = [...progressRecords, record]
    setProgressRecords(nextRecords)
    window.localStorage.setItem("chemlab-progress", JSON.stringify(nextRecords))
    progressSaved.current = true
  }, [showResults, studentName, score, questionBank.length, progressRecords])

  const startLesson = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const trimmedName = studentName.trim()
    if (!trimmedName) return
    setStudentName(trimmedName)
    setHasStarted(true)
  }

  const chooseRole = (nextRole: "student" | "teacher") => {
    if (nextRole === "teacher") {
      setShowTeacherLogin(true)
      setTeacherLoginError("")
      return
    }
    setRole(nextRole)
    setHasStarted(false)
  }

  const submitTeacherLogin = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (teacherPasscode !== "0000") {
      setTeacherLoginError("Mã truy cập chưa đúng. Vui lòng thử lại.")
      return
    }
    setShowTeacherLogin(false)
    setTeacherPasscode("")
    setTeacherLoginError("")
    setRole("teacher")
  }

  const saveQuestions = (nextQuestions: Question[]) => {
    setQuestionBank(nextQuestions)
    setSelectedAnswers({})
  }

  if (role === "teacher") {
    return (
      <TeacherDashboard
        questions={questionBank}
        progressRecords={progressRecords}
        videoQuestions={videoQuestions}
        videoSource={videoSource}
        onSaveQuestions={saveQuestions}
        onSaveVideoQuestions={setVideoQuestions}
        onSaveVideoSource={(source) => {
          setVideoSource(source)
          window.localStorage.setItem("chemlab-video-source", source)
        }}
        onExit={() => setRole(null)}
      />
    )
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="container topbar-inner">
          <button
            className="brand"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          >
            <span className="brand-mark">
              <Icon name="atom" size={25} />
            </span>
            <span>
              <strong>CHEMLAB</strong>
              <small>HÓA HỌC 11</small>
            </span>
          </button>
          <nav className="desktop-nav" aria-label="Điều hướng bài học">
            {sections.map((section, index) => (
              <button
                key={section.id}
                onClick={() => goToSection(section.id)}
                className={activeLessonTab === section.id ? "nav-item active" : "nav-item"}
              >
                <span>0{index + 1}</span>
                {section.label}
              </button>
            ))}
          </nav>
          <div className="class-badge">LỚP 11</div>
        </div>
        {activeLessonTab === "kien-thuc" && (
          <div className="knowledge-subbar" role="tablist" aria-label="Mini section Kiến thức">
            <div className="container knowledge-subbar-inner">
              {(sections[0].children ?? []).map((section, index) => (
                <button
                  key={section.id}
                  role="tab"
                  aria-selected={knowledgeTab === index}
                  className={knowledgeTab === index ? "active" : ""}
                  onClick={() => setKnowledgeTab(index as 0 | 1)}
                >
                  <span>0{index + 1}</span>
                  {section.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      <main>
        <section className="hero">
          <div className="orb orb-one" />
          <div className="orb orb-two" />
          <div className="container hero-grid">
            <div className="hero-copy">
              <div className="eyebrow">
                <span>BÀI 1</span>
                <i />
                CHƯƠNG TRÌNH HÓA HỌC 11
              </div>
              <h1>
                Khái niệm về
                <em>cân bằng hóa học</em>
              </h1>
              <p>
                Cùng khám phá thế giới vi mô, nơi các phản ứng không hề dừng lại
                — chúng chỉ tìm thấy một nhịp điệu cân bằng.
              </p>
              <button
                className="primary-button"
                onClick={() => goToSection("kham-pha")}
              >
                Bắt đầu khám phá
                <span>
                  <Icon name="arrow" />
                </span>
              </button>
            </div>

            <div className="hero-visual" aria-label="Minh họa cân bằng hóa học">
              <div className="visual-card">
                <div className="molecule molecule-left">
                  <span className="atom atom-blue" />
                  <span className="bond" />
                  <span className="atom atom-blue" />
                  <small>Chất phản ứng</small>
                </div>
                <div className="equilibrium-symbol">
                  <span>⇌</span>
                  <small>CÂN BẰNG ĐỘNG</small>
                </div>
                <div className="molecule molecule-right">
                  <span className="atom atom-orange" />
                  <span className="bond" />
                  <span className="atom atom-teal" />
                  <small>Sản phẩm</small>
                </div>
                <div className="visual-note">
                  <Icon name="spark" />
                  <span>Tốc độ thuận</span>
                  <b>=</b>
                  <span>Tốc độ nghịch</span>
                </div>
              </div>
              <div className="floating-label label-one">
                v<sub>t</sub>
              </div>
              <div className="floating-label label-two">
                v<sub>n</sub>
              </div>
            </div>
          </div>
          <div className="lesson-strip">
            <div className="container lesson-strip-inner">
              <span>
                THỜI LƯỢNG <strong>45 PHÚT</strong>
              </span>
              <i />
              <span>
                CHỦ ĐỀ <strong>CÂN BẰNG HÓA HỌC</strong>
              </span>
              <i />
              <span>
                MỨC ĐỘ <strong>CƠ BẢN</strong>
              </span>
            </div>
          </div>
        </section>

        {activeLessonTab === "kien-thuc" && (
          <KnowledgeTabs
            activeTab={knowledgeTab}
            onChange={setKnowledgeTab}
            videoQuestions={videoQuestions}
            videoSource={videoSource}
          />
        )}

        {activeLessonTab === "luyen-tap" && (
          <section id="luyen-tap" className="content-section quiz-section">
          <div className="container">
            <SectionHeading
              number="04"
              kicker="LUYỆN TẬP NHANH"
              title="Luyện tập"
              description="Chọn một đáp án cho mỗi câu hỏi. Bạn sẽ nhận được phản hồi và giải thích ngay lập tức."
            />

            <div className="quiz-layout">
              <div className="question-list">
                {questionBank.map((item, questionIndex) => {
                  const selected = selectedAnswers[questionIndex]
                  const hasAnswered = selected !== undefined
                  const isCorrect = selected === item.correct
                  return (
                    <article className="question-card" key={item.question}>
                      <div className="question-title">
                        <span>
                          CÂU {String(questionIndex + 1).padStart(2, "0")}
                        </span>
                        <h3>{item.question}</h3>
                      </div>
                      <div className="answer-grid">
                        {item.answers.map((answer, answerIndex) => {
                          const isSelected = selected === answerIndex
                          const stateClass = isSelected
                            ? isCorrect
                              ? " selected correct"
                              : " selected wrong"
                            : ""
                          return (
                            <button
                              key={answer}
                              className={`answer${stateClass}`}
                              onClick={() =>
                                setSelectedAnswers((current) => ({
                                  ...current,
                                  [questionIndex]: answerIndex,
                                }))
                              }
                            >
                              <span>
                                {String.fromCharCode(65 + answerIndex)}
                              </span>
                              {answer}
                              {isSelected && (
                                <Icon
                                  name={isCorrect ? "check" : "close"}
                                  size={18}
                                />
                              )}
                            </button>
                          )
                        })}
                      </div>
                      {hasAnswered && (
                        <div
                          className={`feedback ${
                            isCorrect ? "success" : "error"
                          }`}
                          role="status"
                        >
                          <Icon name={isCorrect ? "check" : "close"} />
                          <p>
                            <strong>
                              {isCorrect ? "Chính xác!" : "Chưa chính xác."}
                            </strong>
                            {item.explanation}
                          </p>
                        </div>
                      )}
                    </article>
                  )
                })}
              </div>

              <aside className="score-card">
                <span>TIẾN ĐỘ CỦA BẠN</span>
                <div
                  className="score-ring"
                  style={
                    {
                      "--score": `${(answeredCount / questionBank.length) * 100}%`,
                    } as React.CSSProperties
                  }
                >
                  <div>
                    <strong>{answeredCount}</strong>
                    <small>/ {questionBank.length}</small>
                  </div>
                </div>
                <h3>
                  {answeredCount === questionBank.length
                    ? `${score}/${questionBank.length} câu đúng`
                    : "Tiếp tục nhé!"}
                </h3>
                <p>
                  {answeredCount === questionBank.length
                    ? "Bạn đã hoàn thành phần luyện tập."
                    : "Hoàn thành các câu hỏi để xem kết quả."}
                </p>
                <div className="progress-track">
                  <i
                    style={{
                      width: `${(answeredCount / questionBank.length) * 100}%`,
                    }}
                  />
                </div>
                {answeredCount > 0 && (
                  <button
                    className="reset-button"
                    onClick={() => {
                      setSelectedAnswers({})
                      setShowResults(false)
                    }}
                  >
                    Làm lại từ đầu
                  </button>
                )}
                {hasCompletedQuiz && (
                  <button
                    className="result-button"
                    onClick={() => setShowResults(true)}
                  >
                    Xem đánh giá kết quả
                  </button>
                )}
              </aside>
            </div>
          </div>
          </section>
        )}

        {activeLessonTab === "van-dung" && (
          <section id="van-dung" className="content-section application-section">
          <div className="container">
            <SectionHeading
              number="05"
              kicker="VẬN DỤNG THỰC TẾ"
              title="Thử thách kỹ sư môi trường"
              description="Vận dụng nguyên lí chuyển dịch cân bằng để giải quyết một vấn đề gần gũi trong đời sống."
            />
            <article className="scenario-card">
              <div className="scenario-brief">
                <span className="role-badge">
                  <Icon name="spark" size={18} /> VAI TRÒ CỦA BẠN
                </span>
                <h3>Kỹ sư xử lý hồ nước sinh thái</h3>
                <p>
                  Một hồ nước sinh thái xuất hiện mùi trứng thối do khí H₂S hòa
                  tan. Trong nước tồn tại cân bằng:
                </p>
                <div className="scenario-equation">
                  H₂S(aq) ⇌ H⁺(aq) + HS⁻(aq)
                </div>
              </div>
              <div className="mission-panel">
                <span>NHIỆM VỤ THỰC TẾ</span>
                <h3>Đề xuất phương án giảm mùi H₂S</h3>
                <p>
                  Dựa vào nguyên lí Le Chatelier, hãy lựa chọn biện pháp tác
                  động đến pH hoặc loại bỏ một cấu tử để cân bằng chuyển dịch
                  theo chiều làm giảm H₂S.
                </p>
                <div className="mission-hints">
                  <div>
                    <b>01</b>
                    <span>Dự đoán chiều chuyển dịch khi giảm nồng độ H⁺.</span>
                  </div>
                  <div>
                    <b>02</b>
                    <span>
                      Giải thích vì sao sục khí có thể hỗ trợ xử lý mùi.
                    </span>
                  </div>
                  <div>
                    <b>03</b>
                    <span>Đề xuất cách làm an toàn cho hệ sinh thái.</span>
                  </div>
                </div>
              </div>
            </article>
          </div>
          </section>
        )}
      </main>

      <footer>
        <div className="container footer-inner">
          <div className="footer-brand">
            <Icon name="atom" />
            <span>
              <strong>CHEMLAB</strong>Học liệu số Hóa học 11
            </span>
          </div>
          <p>Nội dung mẫu • Sẵn sàng để giáo viên tùy chỉnh</p>
        </div>
      </footer>

      {role === null && (
        <div className="monitor-overlay student-entry-overlay">
          <div className="monitor-dialog role-dialog">
            <div className="monitor-icon entry-icon">
              <Icon name="atom" size={28} />
            </div>
            <span>CHEMLAB • HÓA HỌC 11</span>
            <h2>Chọn vai trò của bạn</h2>
            <p>Chọn cách truy cập để bắt đầu sử dụng học liệu.</p>
            <div className="role-choice-grid">
              <button onClick={() => chooseRole("student")}>
                <Icon name="book" size={24} />
                <strong>Học sinh</strong>
                <small>Học bài và làm bài luyện tập</small>
              </button>
              <button onClick={() => chooseRole("teacher")}>
                <Icon name="quiz" size={24} />
                <strong>Giáo viên</strong>
                <small>Xem số liệu và chỉnh sửa câu hỏi</small>
              </button>
            </div>
          </div>
        </div>
      )}

      {showTeacherLogin && (
        <div className="monitor-overlay teacher-login-overlay">
          <div className="monitor-dialog teacher-login-dialog">
            <div className="monitor-icon entry-icon">
              <Icon name="quiz" size={28} />
            </div>
            <span>KHU VỰC GIÁO VIÊN</span>
            <h2>Nhập mã truy cập</h2>
            <p>Mã này dùng để mở dashboard quản lý học liệu.</p>
            <form className="student-entry-form" onSubmit={submitTeacherLogin}>
              <label htmlFor="teacher-passcode">Mã giáo viên</label>
              <input
                id="teacher-passcode"
                className="student-name-input"
                type="password"
                inputMode="numeric"
                maxLength={4}
                value={teacherPasscode}
                onChange={(event) => {
                  setTeacherPasscode(event.target.value.replace(/\D/g, ""))
                  setTeacherLoginError("")
                }}
                placeholder="Nhập 4 chữ số"
                autoFocus
                required
              />
              {teacherLoginError && (
                <small className="teacher-login-error">{teacherLoginError}</small>
              )}
              <button type="submit">Vào khu vực giáo viên</button>
              <button
                type="button"
                className="teacher-cancel-button"
                onClick={() => setShowTeacherLogin(false)}
              >
                Quay lại
              </button>
            </form>
          </div>
        </div>
      )}

      {role === "student" && !hasStarted && (
        <div className="monitor-overlay student-entry-overlay">
          <div className="monitor-dialog student-entry-dialog">
            <div className="monitor-icon entry-icon">
              <Icon name="atom" size={28} />
            </div>
            <span>BẮT ĐẦU BÀI HỌC</span>
            <h2>Chào mừng em đến với CHEMLAB</h2>
            <p>Nhập tên để hệ thống ghi nhận kết quả học tập của em.</p>
            <form className="student-entry-form" onSubmit={startLesson}>
              <label htmlFor="student-name">Tên học sinh</label>
              <input
                id="student-name"
                className="student-name-input"
                value={studentName}
                onChange={(event) => setStudentName(event.target.value)}
                placeholder="Ví dụ: Nguyễn Minh Anh"
                autoFocus
                required
              />
              <button type="submit">Bắt đầu học</button>
            </form>
          </div>
        </div>
      )}

      {showResults && (
        <div className="monitor-overlay result-overlay">
          <div className="monitor-dialog result-dialog">
            <div className="monitor-icon result-icon">
              <Icon name="check" size={28} />
            </div>
            <span>ĐÁNH GIÁ HOÀN THÀNH HỌC LIỆU</span>
            <h2>{studentName}</h2>
            <div className="result-score">
              <strong>{score}/{questionBank.length}</strong>
              <small>câu đúng</small>
            </div>
            <div className="result-badge">{resultLabel}</div>
            <p>{resultMessage}</p>
            <div className="result-actions">
              <button onClick={() => setShowResults(false)}>Xem lại bài học</button>
              <button
                className="result-secondary-button"
                onClick={() => {
                  setSelectedAnswers({})
                  setShowResults(false)
                }}
              >
                Làm lại bài
              </button>
            </div>
          </div>
        </div>
      )}

      {showWarning && !isLocked && (
        <div
          className="monitor-overlay"
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="warning-title"
        >
          <div className="monitor-dialog warning-dialog">
            <div className="monitor-icon">
              <Icon name="close" size={28} />
            </div>
            <span>GIÁM SÁT HỌC TẬP • LẦN {violationCount}/2</span>
            <h2 id="warning-title">
              Cảnh báo: Bạn đang rời khỏi trang học tập!
            </h2>
            <p>
              Hãy tập trung hoàn thành bài học. Bài học sẽ bị khóa ở lần vi phạm
              thứ 3.
            </p>
            <button onClick={() => setShowWarning(false)}>
              Tôi đã hiểu, tiếp tục học
            </button>
          </div>
        </div>
      )}

      {isLocked && (
        <div
          className="monitor-overlay locked"
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="locked-title"
        >
          <div className="monitor-dialog locked-dialog">
            <div className="monitor-icon">
              <Icon name="close" size={30} />
            </div>
            <span>BÀI HỌC ĐÃ BỊ KHÓA</span>
            <h2 id="locked-title">
              Bạn đã thoát màn hình quá số lần quy định.
            </h2>
            <p>Bài học đã bị khóa, vui lòng liên hệ giáo viên!</p>
            <div className="locked-count">
              03 <small>LẦN VI PHẠM</small>
            </div>
          </div>
        </div>
      )}

      <nav
        className="mobile-nav"
        aria-label="Điều hướng bài học trên điện thoại"
      >
        {sections.map((section) => (
          <button
            key={section.id}
            onClick={() => goToSection(section.id)}
            className={activeLessonTab === section.id ? "active" : ""}
          >
            <Icon name={section.icon} />
            <span>{section.label}</span>
          </button>
        ))}
      </nav>
    </div>
  )
}

function KnowledgeTabs({
  activeTab,
  onChange,
  videoQuestions,
  videoSource,
}: {
  activeTab: 0 | 1
  onChange: (tab: 0 | 1) => void
  videoQuestions: VideoQuestion[]
  videoSource: string
}) {
  return (
    <section id="kien-thuc" className="content-section knowledge-section">
      <div className="container">
        <SectionHeading
          number="01"
          kicker="KHÔNG GIAN KIẾN THỨC TƯƠNG TÁC"
          title="Khám phá theo từng mạch kiến thức"
          description="Chọn một tab để học khái niệm, xem video, quan sát mô phỏng và rút ra kết luận."
        />
        {activeTab === 0 ? (
          <div className="knowledge-tab-panel" role="tabpanel">
            <IrreversibleReaction />
            <ReversibleReaction />
          </div>
        ) : (
          <div className="knowledge-tab-panel" role="tabpanel">
            <div className="knowledge-concept-banner">
              <span>KHÁI NIỆM TRỌNG TÂM</span>
              <h3>Cân bằng hóa học là cân bằng động</h3>
              <p>
                Khi tốc độ phản ứng thuận bằng tốc độ phản ứng nghịch, nồng độ
                các chất không đổi theo thời gian nhưng phản ứng vẫn tiếp diễn.
              </p>
              <div className="knowledge-equation">v<sub>thuận</sub> = v<sub>nghịch</sub></div>
            </div>
            <div className="knowledge-resource-heading">
              <span>VIDEO TƯƠNG TÁC VỀ CHUYỂN DỊCH CÂN BẰNG</span>
              <h3>Quan sát ảnh hưởng của nhiệt độ</h3>
            </div>
            <InteractiveVideoLesson
              videoQuestions={videoQuestions}
              videoSource={videoSource}
            />
            <ExperimentFrame
              index="02"
              title="Mô phỏng 2NO₂(g) ⇌ N₂O₄(g)"
              prompt="Thay đổi nhiệt độ và quan sát sự chuyển dịch của cân bằng."
              simulation="no2"
            />
            <div className="knowledge-summary teal-summary">
              <span>KẾT THÚC TAB 02</span>
              <strong>Ở trạng thái cân bằng, tốc độ hai chiều bằng nhau chứ không phải phản ứng đã dừng.</strong>
            </div>
          </div>
        )}
      </div>
    </section>
  )
}

function TeacherDashboard({
  questions,
  progressRecords,
  videoQuestions,
  videoSource,
  onSaveQuestions,
  onSaveVideoQuestions,
  onSaveVideoSource,
  onExit,
}: {
  questions: Question[]
  progressRecords: ProgressRecord[]
  videoQuestions: VideoQuestion[]
  videoSource: string
  onSaveQuestions: (questions: Question[]) => void
  onSaveVideoQuestions: (questions: VideoQuestion[]) => void
  onSaveVideoSource: (source: string) => void
  onExit: () => void
}) {
  const [draftQuestions, setDraftQuestions] = useState(questions)
  const [draftVideoQuestions, setDraftVideoQuestions] = useState(videoQuestions)
  const [videoSaved, setVideoSaved] = useState(false)
  const [videoFileName, setVideoFileName] = useState(
    videoSource.startsWith("data:") ? "Video đã tải lên" : "bai-1-anh-huong-nhiet-do.mp4",
  )
  const [saved, setSaved] = useState(false)
  const studentCount = new Set(progressRecords.map((record) => record.studentName)).size
  const completedCount = progressRecords.length
  const averageScore = completedCount
    ? Math.round(
        (progressRecords.reduce(
          (total, record) => total + (record.score / record.total) * 100,
          0,
        ) /
          completedCount) *
          10,
      ) / 10
    : 0

  const updateQuestion = (index: number, update: Partial<Question>) => {
    setDraftQuestions((current) =>
      current.map((question, questionIndex) =>
        questionIndex === index ? { ...question, ...update } : question,
      ),
    )
    setSaved(false)
  }

  const updateAnswer = (questionIndex: number, answerIndex: number, text: string) => {
    setDraftQuestions((current) =>
      current.map((question, index) => {
        if (index !== questionIndex) return question
        const answers = [...question.answers]
        answers[answerIndex] = text
        return { ...question, answers }
      }),
    )
    setSaved(false)
  }

  const saveChanges = () => {
    onSaveQuestions(draftQuestions)
    setSaved(true)
  }

  const updateVideoQuestion = (
    index: number,
    update: Partial<VideoQuestion>,
  ) => {
    setDraftVideoQuestions((current) =>
      current.map((question, questionIndex) =>
        questionIndex === index ? ({ ...question, ...update } as VideoQuestion) : question,
      ),
    )
    setVideoSaved(false)
  }

  const changeVideoQuestionType = (index: number, type: "choice" | "fill") => {
    setDraftVideoQuestions((current) =>
      current.map((question, questionIndex) => {
        if (questionIndex !== index || question.type === type) return question
        if (type === "choice") {
          const answer = question.type === "fill" ? question.fields[0]?.acceptedAnswers[0] || "Đáp án" : "Đáp án đúng"
          return {
            id: question.id,
            time: question.time,
            type: "choice",
            question: question.question,
            choices: [
              { key: "A", text: answer },
              { key: "B", text: "Phương án B" },
              { key: "C", text: "Phương án C" },
              { key: "D", text: "Phương án D" },
            ],
            correctAnswer: "A",
            explanation: question.explanation,
          }
        }
        return {
          id: question.id,
          time: question.time,
          type: "fill",
          question: question.question,
          fields: [{ key: "answer", label: "Đáp án", acceptedAnswers: question.type === "choice" ? [question.choices[0]?.text || ""] : [""] }],
          explanation: question.explanation,
        }
      }),
    )
    setVideoSaved(false)
  }

  const saveVideoChanges = () => {
    onSaveVideoQuestions(draftVideoQuestions)
    setVideoSaved(true)
  }

  const handleVideoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      if (typeof reader.result !== "string") return
      onSaveVideoSource(reader.result)
      setVideoFileName(file.name)
    }
    reader.readAsDataURL(file)
  }

  return (
    <div className="teacher-shell">
      <header className="teacher-header">
        <div>
          <span className="teacher-kicker">CHEMLAB • KHU VỰC GIÁO VIÊN</span>
          <h1>Bảng điều khiển lớp học</h1>
          <p>Theo dõi tiến trình và cập nhật nội dung luyện tập.</p>
        </div>
        <button className="teacher-exit-button" onClick={onExit}>
          <Icon name="arrow" size={16} /> Về màn hình chọn vai trò
        </button>
      </header>

      <main className="teacher-main">
        <section className="teacher-stat-grid" aria-label="Thống kê lớp học">
          <article className="teacher-stat-card">
            <span>HỌC SINH ĐÃ HOÀN THÀNH</span>
            <strong>{studentCount}</strong>
            <small>Số học sinh khác nhau</small>
          </article>
          <article className="teacher-stat-card teal-stat">
            <span>LƯỢT HOÀN THÀNH</span>
            <strong>{completedCount}</strong>
            <small>Tổng số bài đã nộp</small>
          </article>
          <article className="teacher-stat-card orange-stat">
            <span>ĐIỂM TRUNG BÌNH</span>
            <strong>{averageScore}%</strong>
            <small>Trên các lượt đã nộp</small>
          </article>
        </section>

        <section className="teacher-panel">
          <div className="teacher-panel-heading">
            <div>
              <span>TIẾN TRÌNH HỌC SINH</span>
              <h2>Kết quả gần đây</h2>
            </div>
            <span className="teacher-local-note">Dữ liệu lưu trên trình duyệt này</span>
          </div>
          {progressRecords.length === 0 ? (
            <div className="teacher-empty-state">
              Chưa có lượt hoàn thành nào. Học sinh sẽ xuất hiện ở đây sau khi xem
              kết quả.
            </div>
          ) : (
            <div className="progress-table-wrap">
              <table className="progress-table">
                <thead>
                  <tr>
                    <th>Học sinh</th>
                    <th>Điểm</th>
                    <th>Đánh giá</th>
                    <th>Thời gian</th>
                  </tr>
                </thead>
                <tbody>
                  {[...progressRecords].reverse().map((record) => {
                    const percentage = Math.round((record.score / record.total) * 100)
                    return (
                      <tr key={record.id}>
                        <td>{record.studentName}</td>
                        <td><strong>{record.score}/{record.total}</strong></td>
                        <td><span className="progress-result">{percentage}%</span></td>
                        <td>{new Date(record.completedAt).toLocaleString("vi-VN")}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <section className="teacher-panel video-editor-panel">
          <div className="teacher-panel-heading">
            <div>
              <span>VIDEO TAB 01</span>
              <h2>Cấu hình video tương tác</h2>
            </div>
            <button className="save-question-button" onClick={saveVideoChanges}>
              <Icon name="check" size={16} /> {videoSaved ? "Đã lưu" : "Lưu cấu hình video"}
            </button>
          </div>
          <label className="video-upload-control">
            <span>Tải video bài giảng</span>
            <small>{videoFileName}</small>
            <input type="file" accept="video/*" onChange={handleVideoUpload} />
          </label>
          <div className="video-editor-list">
            {draftVideoQuestions.map((videoQuestion, index) => (
              <article className="video-editor-row" key={videoQuestion.id}>
                <div className="video-editor-index">CÂU {String(index + 1).padStart(2, "0")}</div>
                <label>
                  Xuất hiện tại (giây)
                  <input
                    type="number"
                    min="0"
                    value={videoQuestion.time}
                    onChange={(event) => updateVideoQuestion(index, { time: Number(event.target.value) })}
                  />
                </label>
                <label>
                  Loại câu hỏi
                  <select
                    value={videoQuestion.type}
                    onChange={(event) => changeVideoQuestionType(index, event.target.value as "choice" | "fill")}
                  >
                    <option value="choice">Trắc nghiệm</option>
                    <option value="fill">Điền đáp án</option>
                  </select>
                </label>
                <label className="video-editor-question">
                  Nội dung hiển thị
                  <input
                    value={videoQuestion.question}
                    onChange={(event) => updateVideoQuestion(index, { question: event.target.value })}
                  />
                </label>
              </article>
            ))}
          </div>
        </section>

        <section className="teacher-panel question-editor-panel">
          <div className="teacher-panel-heading">
            <div>
              <span>NGÂN HÀNG CÂU HỎI</span>
              <h2>Chỉnh sửa phần luyện tập</h2>
            </div>
            <button className="save-question-button" onClick={saveChanges}>
              <Icon name="check" size={16} /> {saved ? "Đã lưu" : "Lưu thay đổi"}
            </button>
          </div>
          <div className="question-editor-list">
            {draftQuestions.map((question, questionIndex) => (
              <article className="question-editor-card" key={questionIndex}>
                <div className="editor-card-label">CÂU {String(questionIndex + 1).padStart(2, "0")}</div>
                <label>
                  Nội dung câu hỏi
                  <textarea
                    value={question.question}
                    onChange={(event) => updateQuestion(questionIndex, { question: event.target.value })}
                    rows={2}
                  />
                </label>
                <div className="answer-editor-grid">
                  {question.answers.map((answer, answerIndex) => (
                    <label key={answerIndex}>
                      Đáp án {String.fromCharCode(65 + answerIndex)}
                      <input
                        value={answer}
                        onChange={(event) => updateAnswer(questionIndex, answerIndex, event.target.value)}
                      />
                    </label>
                  ))}
                </div>
                <div className="editor-bottom-row">
                  <label>
                    Đáp án đúng
                    <select
                      value={question.correct}
                      onChange={(event) => updateQuestion(questionIndex, { correct: Number(event.target.value) })}
                    >
                      {question.answers.map((_, answerIndex) => (
                        <option key={answerIndex} value={answerIndex}>
                          {String.fromCharCode(65 + answerIndex)}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="explanation-field">
                    Giải thích
                    <input
                      value={question.explanation}
                      onChange={(event) => updateQuestion(questionIndex, { explanation: event.target.value })}
                    />
                  </label>
                </div>
              </article>
            ))}
          </div>
        </section>
      </main>
    </div>
  )
}

function ExperimentFrame({
  index,
  title,
  prompt,
  simulation,
  externalLink,
}: {
  index: string
  title: string
  prompt: string
  simulation: "hi" | "no2"
  externalLink?: string
}) {
  return (
    <article className="experiment-card">
      <div className="experiment-title">
        <span>THÍ NGHIỆM {index}</span>
        <h3>{title}</h3>
        <p>{prompt}</p>
      </div>
      <div className="lab-frame-shell">
        <div className="lab-toolbar">
          <div className="window-dots">
            <i />
            <i />
            <i />
          </div>
          <span>PHÒNG THÍ NGHIỆM MÔ PHỎNG</span>
          <div className="embed-status">
            <i /> MÔ PHỎNG ĐANG HOẠT ĐỘNG
          </div>
        </div>
        <div className="simulation-wrap">
          {simulation === "hi" ? <HISimulation /> : <NO2Simulation />}
        </div>
        <div className="lab-footer">
          <div>
            <Icon name="flask" />
            <span>
              <strong>Nhiệm vụ khám phá</strong>
              {prompt}
            </span>
          </div>
          {externalLink ? (
            <a href={externalLink} target="_blank" rel="noreferrer">
              Mở mô phỏng tham khảo <Icon name="external" size={14} />
            </a>
          ) : (
            <p>Thao tác trực tiếp với các điều khiển trong mô phỏng.</p>
          )}
        </div>
      </div>
    </article>
  )
}

function NO2Simulation() {
  const [temperature, setTemperature] = useState(25)
  const [no2Ratio, setNo2Ratio] = useState(0.32)
  const targetRatio = 0.12 + 0.76 / (1 + Math.exp(-(temperature - 35) / 8))

  useEffect(() => {
    const timer = window.setInterval(() => {
      setNo2Ratio((current) => {
        if (Math.abs(current - targetRatio) < 0.005) return targetRatio
        return current + (targetRatio - current) * 0.09
      })
    }, 70)
    return () => window.clearInterval(timer)
  }, [targetRatio])

  const no2Count = Math.round(no2Ratio * 18)
  const n2o4Count = Math.round((18 - no2Count) / 2)
  const direction =
    temperature >= 36
      ? "Nhiệt độ cao: cân bằng chuyển dịch sang trái, tạo thêm NO₂."
      : temperature <= 18
        ? "Nhiệt độ thấp: cân bằng chuyển dịch sang phải, tạo thêm N₂O₄."
        : "Hệ đang thích nghi với nhiệt độ môi trường."

  return (
    <div className="chem-simulation no2-simulation">
      <div className="simulation-stage">
        <div className="stage-topline">
          <span>BÌNH KHÍ KÍN</span>
          <b>{temperature}°C</b>
        </div>
        <div
          className="gas-chamber"
          style={{ "--gas-opacity": no2Ratio.toFixed(2) } as React.CSSProperties}
          aria-label={`Bình khí ở ${temperature} độ C`}
        >
          <div className="gas-particles">
            {Array.from({ length: no2Count }).map((_, index) => (
              <i className="gas-particle no2-particle" key={`no2-${index}`} />
            ))}
            {Array.from({ length: n2o4Count }).map((_, index) => (
              <i className="gas-particle n2o4-particle" key={`n2o4-${index}`} />
            ))}
          </div>
          <span>Màu nâu đỏ tăng khi nồng độ NO₂ tăng</span>
        </div>
        <div className="particle-legend">
          <span><i className="legend-no2" /> NO₂ (nâu đỏ)</span>
          <span><i className="legend-n2o4" /> N₂O₄ (không màu)</span>
        </div>
      </div>
      <div className="simulation-controls">
        <div className="formula-display no2-formula">
          <span>2NO₂(g)</span><strong>⇌</strong><span>N₂O₄(g)</span>
        </div>
        <p className="simulation-state">{direction}</p>
        <div className="temperature-readout">
          <div><span>NHIỆT ĐỘ</span><strong>{temperature}°C</strong></div>
          <div><span>TỈ LỆ NO₂</span><strong>{Math.round(no2Ratio * 100)}%</strong></div>
        </div>
        <label className="temperature-control">
          <span><b>Lạnh</b><b>Nóng</b></span>
          <input
            type="range"
            min="5"
            max="60"
            value={temperature}
            onChange={(event) => setTemperature(Number(event.target.value))}
          />
        </label>
        <div className="preset-buttons">
          <button onClick={() => setTemperature(10)}>Làm lạnh 10°C</button>
          <button onClick={() => setTemperature(25)}>Phòng 25°C</button>
          <button onClick={() => setTemperature(55)}>Đun nóng 55°C</button>
        </div>
      </div>
    </div>
  )
}

function SectionHeading({
  number,
  kicker,
  title,
  description,
  light = false,
}: {
  number: string
  kicker: string
  title: string
  description: string
  light?: boolean
}) {
  return (
    <div className={`section-heading${light ? " light" : ""}`}>
      <div className="section-number">{number}</div>
      <div>
        <span>{kicker}</span>
        <h2>{title}</h2>
        <p>{description}</p>
      </div>
    </div>
  )
}

export default App
