import { useEffect, useRef, useState } from "react"
import HISimulation from "./HISimulation"

type YouTubePlayer = {
  playVideo: () => void
  pauseVideo: () => void
  seekTo: (seconds: number, allowSeekAhead: boolean) => void
  getCurrentTime: () => number
  destroy: () => void
}

type YouTubeApi = {
  Player: new (
    element: HTMLElement,
    options: {
      videoId: string
      playerVars: Record<string, number>
      events: {
        onReady: () => void
        onStateChange: (event: { data: number }) => void
      }
    },
  ) => YouTubePlayer
  PlayerState: { PLAYING: number }
}

type OneWayQuestion =
  | {
      id: string
      time: number
      type: "choice"
      question: string
      choices: Array<{ key: string; text: string }>
      correct: string
      explanation: string
    }
  | {
      id: string
      time: number
      type: "fill"
      question: string
      fields: Array<{
        key: string
        label: string
        accepted: string[]
      }>
      explanation: string
    }

const ONE_WAY_VIDEO_ID = "9oY5JFHB5uI"

// Các mốc câu hỏi của video phản ứng một chiều.
const ONE_WAY_QUESTIONS: OneWayQuestion[] = [
  {
    id: "ket-tua-moi",
    time: 79,
    type: "choice",
    question: "Sau khi phản ứng xảy ra, trong ống nghiệm xuất hiện chất gì mới?",
    choices: [
      {
        key: "A",
        text: "Kết tủa màu trắng (Barium sulfate – BaSO₄)",
      },
      {
        key: "B",
        text: "Kết tủa màu trắng (Sodium chloride – NaCl)",
      },
      { key: "C", text: "Bọt khí không màu thoát ra khỏi dung dịch" },
      {
        key: "D",
        text: "Kết tủa màu xanh lam (Copper(II) hydroxide – Cu(OH)₂)",
      },
    ],
    correct: "A",
    explanation:
      "Na₂SO₄ tác dụng với BaCl₂ tạo BaSO₄ không tan, xuất hiện ngay dưới dạng kết tủa màu trắng đục.",
  },
  {
    id: "co-phan-ung-nguoc",
    time: 85,
    type: "choice",
    question:
      "Sau khi phản ứng hoàn toàn, BaSO₄ và NaCl có thể tự phản ứng ngược để tạo lại BaCl₂ và Na₂SO₄ ban đầu không?",
    choices: [
      { key: "A", text: "Có" },
      { key: "B", text: "Không" },
    ],
    correct: "B",
    explanation:
      "Không. Trong cùng điều kiện, sản phẩm không tự chuyển ngược thành các chất ban đầu.",
  },
  {
    id: "dien-khai-niem",
    time: 90,
    type: "fill",
    question: "Hoàn thành kết luận về chiều diễn ra của phản ứng:",
    fields: [
      {
        key: "a",
        label: "Phản ứng diễn ra theo (a) … chiều",
        accepted: ["một", "mot", "1"],
      },
      {
        key: "b",
        label: "Từ (b) …",
        accepted: ["chất ban đầu", "chat ban dau", "ban đầu", "ban dau"],
      },
      {
        key: "c",
        label: "Sang (c) …",
        accepted: ["chất sản phẩm", "chat san pham", "sản phẩm", "san pham"],
      },
    ],
    explanation:
      "Phản ứng một chiều chỉ diễn ra từ chất ban đầu tạo thành sản phẩm trong cùng điều kiện.",
  },
]

let youtubeApiPromise: Promise<YouTubeApi> | null = null

function loadYouTubeApi() {
  const youtubeWindow = window as typeof window & {
    YT?: YouTubeApi
    onYouTubeIframeAPIReady?: () => void
  }
  if (youtubeWindow.YT?.Player) return Promise.resolve(youtubeWindow.YT)
  if (youtubeApiPromise) return youtubeApiPromise

  youtubeApiPromise = new Promise<YouTubeApi>((resolve) => {
    const previousCallback = youtubeWindow.onYouTubeIframeAPIReady
    youtubeWindow.onYouTubeIframeAPIReady = () => {
      previousCallback?.()
      resolve(youtubeWindow.YT!)
    }
    if (!document.getElementById("youtube-iframe-api")) {
      const script = document.createElement("script")
      script.id = "youtube-iframe-api"
      script.src = "https://www.youtube.com/iframe_api"
      document.head.appendChild(script)
    }
  })
  return youtubeApiPromise
}

function normalizeAnswer(value: string) {
  return value
    .trim()
    .toLocaleLowerCase("vi")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .replace(/\s+/g, " ")
}

function formatTime(seconds: number) {
  return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`
}

export function IrreversibleReaction() {
  const playerHostRef = useRef<HTMLDivElement>(null)
  const playerRef = useRef<YouTubePlayer | null>(null)
  const pollingRef = useRef<number | null>(null)
  const completedRef = useRef<Set<string>>(new Set())
  const activeIndexRef = useRef<number | null>(null)
  const resumeTimerRef = useRef<number | null>(null)
  const [activeIndex, setActiveIndex] = useState<number | null>(null)
  const [completedIds, setCompletedIds] = useState<Set<string>>(new Set())
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null)
  const [isPlayerReady, setIsPlayerReady] = useState(false)
  const [isPart1Answered, setIsPart1Answered] = useState(false)

  useEffect(() => {
    completedRef.current = completedIds
  }, [completedIds])

  useEffect(() => {
    activeIndexRef.current = activeIndex
  }, [activeIndex])

  useEffect(() => {
    let cancelled = false

    loadYouTubeApi().then((YT) => {
      if (cancelled || !playerHostRef.current) return
      playerRef.current = new YT.Player(playerHostRef.current, {
        videoId: ONE_WAY_VIDEO_ID,
        playerVars: {
          rel: 0,
          modestbranding: 1,
          playsinline: 1,
          disablekb: 1,
        },
        events: {
          onReady: () => setIsPlayerReady(true),
          onStateChange: (event) => {
            if (event.data !== YT.PlayerState.PLAYING) return
            if (activeIndexRef.current !== null) playerRef.current?.pauseVideo()
          },
        },
      })

      pollingRef.current = window.setInterval(() => {
        const player = playerRef.current
        if (!player || activeIndexRef.current !== null) return
        const currentTime = player.getCurrentTime()
        const questionIndex = ONE_WAY_QUESTIONS.findIndex(
          (question) =>
            !completedRef.current.has(question.id) &&
            currentTime >= question.time - 0.1,
        )

        if (questionIndex >= 0) {
          const question = ONE_WAY_QUESTIONS[questionIndex]
          player.pauseVideo()
          player.seekTo(question.time, true)
          activeIndexRef.current = questionIndex
          setActiveIndex(questionIndex)
          setAnswers({})
          setFeedback(null)
        }
      }, 150)
    })

    return () => {
      cancelled = true
      if (pollingRef.current !== null) window.clearInterval(pollingRef.current)
      if (resumeTimerRef.current !== null) {
        window.clearTimeout(resumeTimerRef.current)
      }
      playerRef.current?.destroy()
      playerRef.current = null
    }
  }, [])

  const activeQuestion =
    activeIndex === null ? null : ONE_WAY_QUESTIONS[activeIndex]

  const completeQuestion = () => {
    if (!activeQuestion) return
    const nextCompleted = new Set(completedRef.current)
    nextCompleted.add(activeQuestion.id)
    completedRef.current = nextCompleted
    setCompletedIds(nextCompleted)
    setFeedback("correct")

    const hasFinished = nextCompleted.size === ONE_WAY_QUESTIONS.length
    if (hasFinished) setIsPart1Answered(true)

    resumeTimerRef.current = window.setTimeout(() => {
      activeIndexRef.current = null
      setActiveIndex(null)
      setFeedback(null)
      playerRef.current?.playVideo()
    }, 1800)
  }

  const submitAnswer = () => {
    if (!activeQuestion) return

    const isCorrect =
      activeQuestion.type === "choice"
        ? answers.choice === activeQuestion.correct
        : activeQuestion.fields.every((field) =>
            field.accepted
              .map(normalizeAnswer)
              .includes(normalizeAnswer(answers[field.key] ?? "")),
          )

    if (isCorrect) completeQuestion()
    else setFeedback("incorrect")
  }

  return (
    <article className="reaction-learning-part one-way-part">
      <div className="reaction-part-heading">
        <div className="part-number">01</div>
        <div>
          <span>PHẦN 1 • PHẢN ỨNG MỘT CHIỀU</span>
          <h3>Quan sát sự tạo thành kết tủa BaSO₄</h3>
          <p>Hoàn thành lần lượt ba bước để mở khóa kiến thức cần nhớ.</p>
        </div>
      </div>

      <div className="learning-flow">
        <span className="active">1. Xem video</span>
        <i />
        <span className={completedIds.size > 0 ? "active" : ""}>2. Trả lời</span>
        <i />
        <span className={isPart1Answered ? "active" : ""}>3. Kết luận</span>
      </div>

      <div className="one-way-workspace">
        <section className="reaction-media-card">
          <div className="reaction-card-label">
            <span>VIDEO HIỆN TƯỢNG</span>
            <b>{isPlayerReady ? "SẴN SÀNG" : "ĐANG TẢI…"}</b>
          </div>
          <div className="youtube-frame" ref={playerHostRef} />
          <div className="checkpoint-list">
            {ONE_WAY_QUESTIONS.map((question, index) => (
              <div
                key={question.id}
                className={completedIds.has(question.id) ? "completed" : ""}
              >
                <b>{completedIds.has(question.id) ? "✓" : index + 1}</b>
                <span>{formatTime(question.time)}</span>
              </div>
            ))}
          </div>
          <p className="checkpoint-note">
            Video tự dừng tại từng câu hỏi và không thể tua qua câu chưa hoàn thành.
          </p>
        </section>

        <section className="reaction-question-panel">
          <div className="reaction-card-label">
            <span>CÂU HỎI QUAN SÁT</span>
            <b>{completedIds.size}/{ONE_WAY_QUESTIONS.length} HOÀN THÀNH</b>
          </div>

          {activeQuestion ? (
            <div className="checkpoint-question">
              <small>DỪNG TẠI {formatTime(activeQuestion.time)}</small>
              <h4>{activeQuestion.question}</h4>
              {activeQuestion.type === "choice" ? (
                <div className="reaction-choice-list">
                  {activeQuestion.choices.map((choice) => (
                    <button
                      key={choice.key}
                      className={answers.choice === choice.key ? "selected" : ""}
                      onClick={() => {
                        setAnswers({ choice: choice.key })
                        setFeedback(null)
                      }}
                      disabled={feedback === "correct"}
                    >
                      <span>{choice.key}</span>
                      {choice.text}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="reaction-fill-list">
                  {activeQuestion.fields.map((field) => (
                    <label key={field.key}>
                      <span>{field.label}</span>
                      <input
                        value={answers[field.key] ?? ""}
                        onChange={(event) => {
                          setAnswers((current) => ({
                            ...current,
                            [field.key]: event.target.value,
                          }))
                          setFeedback(null)
                        }}
                        disabled={feedback === "correct"}
                        placeholder="Nhập đáp án"
                      />
                    </label>
                  ))}
                </div>
              )}
              <button
                className="reaction-submit"
                onClick={submitAnswer}
                disabled={feedback === "correct"}
              >
                Nộp câu trả lời
              </button>
              {feedback && (
                <div className={`reaction-feedback ${feedback}`} role="status">
                  <strong>
                    {feedback === "correct"
                      ? "Chính xác!"
                      : "Chưa đúng, hãy quan sát lại."}
                  </strong>
                  {feedback === "correct" && <p>{activeQuestion.explanation}</p>}
                </div>
              )}
            </div>
          ) : (
            <div className="question-waiting">
              <div className="waiting-symbol">?</div>
              <h4>
                {isPart1Answered
                  ? "Bạn đã hoàn thành phần câu hỏi"
                  : "Hãy phát video để bắt đầu"}
              </h4>
              <p>
                Câu hỏi sẽ xuất hiện ở đây khi video đến mốc kiến thức tương ứng.
              </p>
            </div>
          )}
        </section>
      </div>

      {isPart1Answered && (
        <div className="reaction-conclusion revealed" aria-live="polite">
          <>
            <span>KẾT LUẬN VÀ KIẾN THỨC CẦN NHỚ</span>
            <h4>Phản ứng một chiều chỉ diễn ra theo một hướng xác định</h4>
            <p>
              Chất phản ứng tạo thành sản phẩm và sản phẩm không tự phản ứng để
              tạo lại chất ban đầu trong cùng điều kiện. Ví dụ:
            </p>
            <div className="conclusion-equation">
              Na₂SO₄ + BaCl₂ → BaSO₄↓ + 2NaCl
            </div>
          </>
        </div>
      )}
    </article>
  )
}

export function ReversibleReaction() {
  const [selectedAnswer, setSelectedAnswer] = useState("")
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null)
  const [isPart2Answered, setIsPart2Answered] = useState(false)

  const submitAnswer = () => {
    if (selectedAnswer === "dynamic") {
      setFeedback("correct")
      setIsPart2Answered(true)
    } else {
      setFeedback("incorrect")
    }
  }

  return (
    <article className="reaction-learning-part reversible-part">
      <div className="reaction-part-heading">
        <div className="part-number">02</div>
        <div>
          <span>PHẦN 2 • PHẢN ỨNG THUẬN NGHỊCH</span>
          <h3>Quan sát hai chiều của phản ứng H₂ + I₂ ⇌ 2HI</h3>
          <p>Tương tác với mô phỏng, trả lời câu hỏi rồi rút ra kết luận.</p>
        </div>
      </div>

      <div className="learning-flow">
        <span className="active">1. Mô phỏng</span>
        <i />
        <span className={selectedAnswer ? "active" : ""}>2. Trả lời</span>
        <i />
        <span className={isPart2Answered ? "active" : ""}>3. Kết luận</span>
      </div>

      <section className="reversible-simulation-shell">
        <div className="reaction-card-label">
          <span>THÍ NGHIỆM MÔ PHỎNG</span>
          <b>TƯƠNG TÁC TRỰC TIẾP</b>
        </div>
        <HISimulation />
      </section>

      <section className="reversible-question-card">
        <div>
          <span>CÂU HỎI SAU MÔ PHỎNG</span>
          <h4>
            Khi hệ đạt cân bằng, phản ứng thuận và phản ứng nghịch có dừng lại
            không?
          </h4>
        </div>
        <div className="reversible-answer-area">
          <div className="reaction-choice-list compact-choices">
            <button
              className={selectedAnswer === "stop" ? "selected" : ""}
              onClick={() => {
                setSelectedAnswer("stop")
                setFeedback(null)
              }}
            >
              <span>A</span>Cả hai phản ứng dừng hoàn toàn
            </button>
            <button
              className={selectedAnswer === "dynamic" ? "selected" : ""}
              onClick={() => {
                setSelectedAnswer("dynamic")
                setFeedback(null)
              }}
            >
              <span>B</span>Hai phản ứng vẫn diễn ra với tốc độ bằng nhau
            </button>
          </div>
          <button className="reaction-submit" onClick={submitAnswer}>
            Nộp câu trả lời
          </button>
          {feedback && (
            <div className={`reaction-feedback ${feedback}`} role="status">
              <strong>
                {feedback === "correct"
                  ? "Chính xác!"
                  : "Chưa đúng, hãy thử lại."}
              </strong>
            </div>
          )}
        </div>
      </section>

      {isPart2Answered && (
        <div className="reaction-conclusion revealed" aria-live="polite">
          <>
            <span>KẾT LUẬN VÀ KIẾN THỨC CẦN NHỚ</span>
            <h4>Phản ứng thuận nghịch diễn ra theo hai chiều trái ngược</h4>
            <p>
              Trong cùng điều kiện, chất phản ứng tạo thành sản phẩm và sản phẩm
              cũng phản ứng để tạo lại chất ban đầu. Ở cân bằng, hai chiều vẫn
              tiếp diễn với tốc độ bằng nhau.
            </p>
            <div className="conclusion-equation">H₂ + I₂ ⇌ 2HI</div>
          </>
        </div>
      )}
    </article>
  )
}
